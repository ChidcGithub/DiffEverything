fn main() {
    println!("right");
}
