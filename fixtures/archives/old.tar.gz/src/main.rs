fn main() {
    println!("left");
}
